# materials
**Workshops, demos, talks, presentations, and more!**



Here lie all of our teaching materials! These have been made or sourced by your fellow ambassadors. :)

[Intro to Unity Video Series](https://www.youtube.com/channel/UCPN0PJQfB0Y8iKsfnE_cedQ/videos)

[Unity Juice Presentation](https://docs.google.com/presentation/d/1G7W8q7iu48C6-UhRZwTr-Lz52wuGbaNRwITwQ1n2ynw/edit?usp=sharing)

[Campfire VR Workshop](https://docs.google.com/presentation/d/1y52CTjbds-NE-wfep5X-Uoxofz5bDiSrlDMQuWlZiFA/edit?usp=sharing)

[AR Workshop](https://docs.google.com/presentation/d/12U9v1wT0reID6OwAwbBjpRc7CNjn76nCsUwTLr0CIIE/edit?usp=sharing)

[Viking Quest VR Workshop, Unity Roadshow](https://docs.google.com/a/unity3d.com/presentation/d/1y8Wx4AXmb7GYNmuVzFD458oWkNIMICoeUphlEqsLbtA/edit?usp=sharing)

[Unity Programming Tutorials Video Series](https://www.youtube.com/watch?v=eknXlJ4utoM&list=PLs023Yclit4ktHA6NfLOWFyLgAm74p3mJ)

[Unity GUI Tutorials Web Series](https://www.youtube.com/watch?v=6FH-BsR9Bbc&list=PLs023Yclit4kwQga3gDXnFigzhEWSGOkZ)

[Unity Editor Scripting Tutorials](https://www.youtube.com/watch?v=BjlFOcyHfW4&list=PLs023Yclit4nom70pyx0wIxQLWf4Q7nIU)

[Saving Data in Unity Video Series](https://www.youtube.com/watch?v=RkqjZtVbhQg&list=PLs023Yclit4nT0eiTtMa5O_95V-jE4tn9)
