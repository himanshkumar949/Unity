# Workshop Details

## General Workshop Facilitation Guidelines

- Make sure you've gone through the workshop thoroughly yourself first.
- Demo the final product.
- Give students an overview and context of what they're going to learn.
