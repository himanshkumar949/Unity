# Internals

This directory is intended for things that typically don't face the public world, like grant applications.

Index:

- [Applications](applications/)
- [Logos / design assets](logos/)
- Processes
  - [Hackathon sponsorship](processes/hackathon_sponsorship_process.md)
- [Management](management/)
- Miscellaneous
  - [Email copy](email_copy.md) - Template responses for repetitive emails
